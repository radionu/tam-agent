#!/usr/bin/env bash
# Places a TAM download tree into the artifact directory served at
# /downloads/. Run it on the web server as the user that owns the artifact
# directory (on Plesk: the subscription's system user, never root), from the
# extracted tam-downloads directory:
#
#   ./publish-downloads.sh --check DEST     report what would change
#   ./publish-downloads.sh DEST             publish
#
# DEST is the artifact directory, for example
# /var/www/vhosts/mesoco.vn/tam.pmr.vn/tam-artifacts. Files are served from
# DEST/downloads; DEST/publish-log keeps index.html backups and records and
# is not served. A release or installer directory that already exists is
# never changed: identical content is skipped, different content stops the
# publication. Only downloads/index.html is replaced (old copy backed up).

set -euo pipefail
umask 022
tmp=
trap '[ -z "$tmp" ] || rm -rf -- "$tmp"' EXIT
cd "$(dirname "$0")"
SRC=$(pwd)

die() { echo "error: $*" >&2; exit 1; }

CHECK=0
if [ "${1:-}" = --check ]; then CHECK=1; shift; fi
[ $# = 1 ] || die "usage: publish-downloads.sh [--check] DEST"
DEST=$1
case $DEST in /*) ;; *) die "DEST must be an absolute path" ;; esac

[ "$(id -u)" != 0 ] || die "do not run as root; run as the owner of $DEST"
[ -f TREE-SHA256SUMS ] && [ -d downloads ] || die "run from the extracted tam-downloads directory"
sha256sum --quiet -c TREE-SHA256SUMS || die "the extracted files do not match TREE-SHA256SUMS; do not publish"
listed=$(cut -c67- TREE-SHA256SUMS | LC_ALL=C sort)
present=$(find downloads -type f | LC_ALL=C sort)
[ "$listed" = "$present" ] || die "the tree holds files not listed in TREE-SHA256SUMS"
[ -z "$(find downloads \( -type l -o -name '.*' -o \( ! -type f -a ! -type d \) \) -print -quit)" ] || die "the tree contains links or hidden files"

[ -d "$DEST" ] && [ ! -L "$DEST" ] || die "$DEST is not a directory"
for ancestor in "$DEST" "$(dirname "$DEST")"; do
    [ -d "$ancestor" ] && [ ! -L "$ancestor" ] || die "unsafe destination ancestor"
done
[ "$(stat -c %u "$DEST")" = "$(id -u)" ] || die "$DEST does not belong to $(id -un)"
m=$(stat -c %a "$DEST")
(( (8#$m & 8#022) == 0 )) || die "$DEST is writable by group or others (mode $m)"
for d in "$DEST/downloads" "$DEST/publish-log"; do
    if [ -e "$d" ] || [ -L "$d" ]; then
        [ -d "$d" ] && [ ! -L "$d" ] || die "$d is not a directory"
    fi
done

# Release and installer directories in this tree.
[ -z "$(find downloads -type f -links +1 -print -quit)" ] || die "hardlinked source file"
[ -z "$(find downloads -mindepth 3 -type d -print -quit)" ] || die "nested source directory"
for category in downloads/*; do
    case $category in downloads/bootstrap|downloads/runtime|downloads/index.html) ;; *) die "unexpected managed category" ;; esac
done
mapfile -t UNITS < <(find downloads -mindepth 2 -maxdepth 2 -type d | LC_ALL=C sort)

if [ "$CHECK" = 0 ]; then
    mkdir -p -m 755 "$DEST/publish-log"
    exec 9>>"$DEST/publish-log/.lock"
    flock -n 9 || die "another publication is running"
fi

listing() { # DIR -> entry types, names and SHA-256 of regular files
    (cd "$1" && find . -mindepth 1 -printf '%y %p\n' | LC_ALL=C sort &&
        find . -type f | LC_ALL=C sort | xargs -r sha256sum)
}
same_dir() { [ "$(listing "$1")" = "$(listing "$2")" ]; }

plan_new=() plan_same=()
for u in "${UNITS[@]}"; do
    parent=$(dirname "$DEST/$u")
    if [ -e "$parent" ] || [ -L "$parent" ]; then
        [ -d "$parent" ] && [ ! -L "$parent" ] || die "unsafe destination category"
    fi
    if [ -e "$DEST/$u" ] || [ -L "$DEST/$u" ]; then
        [ -d "$DEST/$u" ] && [ ! -L "$DEST/$u" ] && same_dir "$u" "$DEST/$u" ||
            die "$DEST/$u already exists with different content; published directories are never changed. Nothing was changed"
        plan_same+=("$u")
    else
        plan_new+=("$u")
    fi
done
for u in "${plan_same[@]}"; do echo "unchanged (already published): $u"; done
for u in "${plan_new[@]}"; do echo "new: $u"; done
if [ -f "$DEST/downloads/index.html" ] && cmp -s downloads/index.html "$DEST/downloads/index.html"; then
    echo "unchanged: downloads/index.html"; INDEX_NEW=0
else
    echo "replace: downloads/index.html"; INDEX_NEW=1
fi
if [ $CHECK = 1 ]; then echo "CHECK OK (nothing changed)"; exit 0; fi

mkdir -p -m 755 "$DEST/downloads" "$DEST/publish-log"

stamp=$(date -u +%Y%m%dT%H%M%SZ)
for u in "${plan_new[@]}"; do
    [ ! -e "$DEST/$u" ] || die "$DEST/$u appeared during publication; stopping"
    parent=$(dirname "$DEST/$u")
    mkdir -p -m 755 "$parent"
    tmp=$(mktemp -d "$parent/.incoming-XXXXXX")
    cp -- "$u"/* "$tmp/"
    chmod 644 "$tmp"/*
    chmod 755 "$tmp"
    same_dir "$SRC/$u" "$tmp" || { rm -rf "$tmp"; die "copy of $u did not verify"; }
    mv -T -- "$tmp" "$DEST/$u"
    echo "published: $u"
done
if [ $INDEX_NEW = 1 ]; then
    if [ -f "$DEST/downloads/index.html" ]; then
        cp -p -- "$DEST/downloads/index.html" "$DEST/publish-log/index.html.$stamp"
        echo "backup: publish-log/index.html.$stamp"
    fi
    tmp=$(mktemp "$DEST/downloads/.index-XXXXXX")
    cp -- downloads/index.html "$tmp"
    chmod 644 "$tmp"
    mv -T -f -- "$tmp" "$DEST/downloads/index.html"
    echo "published: downloads/index.html"
fi
{
    echo "publication $stamp by $(id -un)"
    for u in "${plan_new[@]}"; do echo "new $u"; done
    for u in "${plan_same[@]}"; do echo "unchanged $u"; done
    echo "index $([ $INDEX_NEW = 1 ] && echo replaced || echo unchanged)"
    cat TREE-SHA256SUMS
} >"$DEST/publish-log/publication-$stamp.txt"
(cd "$DEST" && sha256sum --quiet -c "$SRC/TREE-SHA256SUMS") || die "verification after publication failed"
echo "PUBLISHED OK ($stamp)"
